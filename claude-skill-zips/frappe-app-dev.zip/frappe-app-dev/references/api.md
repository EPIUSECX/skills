# Whitelisted APIs

## Preferred: Methods in DocType controllers

Place whitelisted methods in the controller file — either as Document class methods (doc-level) or as module-level functions (doctype-level). This avoids needing full dotted paths to call them.

### Doc-level methods (on a specific document)

```python
# apps/<app>/<app>/<module>/doctype/expense/expense.py

import frappe
from frappe.model.document import Document

class Expense(Document):
    @frappe.whitelist()
    def approve(self):
        self.status = "Approved"
        self.save()
        return self.status
```

Call from client JS:
```javascript
frappe.call({
    method: "approve",       // just the method name
    doc: frm.doc,
    callback(r) { console.log(r.message); }
});
// or
frm.call("approve");
```

Call from HTTP (v2 API):
```
POST /api/v2/document/Expense/EXP-0001/method/approve
```

### DocType-level functions (module root)

```python
# apps/<app>/<app>/<module>/doctype/expense/expense.py

import frappe

@frappe.whitelist(methods=["GET"])
def get_expense_summary(status: str | None = None):
    filters = {"status": status} if status else {}
    # get_list applies the user's permissions. get_all would return every Expense to any user.
    return frappe.get_list("Expense", filters=filters, fields=["name", "title", "amount"])
```

Call from client JS:
```javascript
frappe.call({
    method: "myapp.mymodule.doctype.expense.expense.get_expense_summary",
    args: { status: "Draft" },
    callback(r) { console.log(r.message); }
});
```

Call from HTTP:
```
POST /api/v2/method/Expense/get_expense_summary
```

## Standalone API files (for non-DocType logic)

Use only when logic doesn't belong to any DocType:

```python
# apps/<app>/<app>/api.py
import frappe

@frappe.whitelist()
def get_dashboard_data():
    return {"total": frappe.db.count("Expense")}
```

For larger apps, organize by feature:
```
apps/<app>/<app>/api/
    __init__.py
    expenses.py
    reports.py
```

## Allow guest access

```python
@frappe.whitelist(allow_guest=True)
def public_endpoint():
    return {"message": "Hello"}
```

## Argument handling

- **Always add type hints** to whitelisted method parameters. Frappe validates and casts arguments based on type hints, preventing type-confusion attacks:
```python
@frappe.whitelist(methods=["POST"])
def create_expense(title: str, amount: float, tags: str | list | None = None):
    # title is guaranteed to be str, amount is cast to float
    tags = frappe.parse_json(tags) if isinstance(tags, str) else tags
    ...
```

Type hints are checked on every request; arguments without hints are not checked. `frappe.call` from the desk sends lists and dicts as JSON strings, so a parameter typed only `list` or `dict` rejects a desk call. Type such parameters `str | list` (or `str | dict`) and parse them, as Frappe's own `frappe.client` does. A JSON request body keeps its JSON types. Query-string and form values arrive as strings.

Signature: `frappe.whitelist(allow_guest=False, xss_safe=False, methods=None)`. Without `methods`, GET, POST, PUT and DELETE are allowed (not PATCH). For guests, string arguments are HTML-sanitized unless `xss_safe=True`.

- Use `frappe.form_dict` for raw request data:
```python
data = frappe.form_dict
```

## Return values

- Return a dict/list → auto-serialized to JSON. `/api/method/...` (v1, and `frappe.call`) wraps it as `{"message": <return_value>}`. `/api/v2/...` and `/api/resource/...` wrap it as `{"data": <return_value>}`.
- For custom HTTP responses:
```python
frappe.response["meta"] = meta
```

## Built-in document APIs (v2)

Frappe provides CRUD APIs automatically via `/api/v2/document/` — no need to write them. Requires **Frappe v15+**.

```
GET    /api/v2/document/<DocType>                          # list (with filters, fields, order_by, limit)
POST   /api/v2/document/<DocType>                          # create
GET    /api/v2/document/<DocType>/<name>/                  # read
PUT    /api/v2/document/<DocType>/<name>/                  # update
DELETE /api/v2/document/<DocType>/<name>/                  # delete
GET    /api/v2/document/<DocType>/<name>/copy              # copy doc
POST   /api/v2/document/<DocType>/<name>/method/<method>/  # call doc method
POST   /api/v2/method/<DocType>/<method>                   # call doctype level method
GET    /api/v2/doctype/<DocType>/meta                      # get DocType meta
GET    /api/v2/doctype/<DocType>/count                     # count records
```

### List query params
`fields` (JSON list), `filters` (JSON dict/list), `order_by`, `start`, `limit` (default 20), `group_by`.

Response includes `has_next_page` boolean for pagination.

### Bulk operations

v2 has no bulk routes. Use the v1 RPC methods:
```
POST /api/method/frappe.desk.reportview.delete_items   # form: doctype, items (JSON list of names)
POST /api/method/frappe.client.bulk_update             # form: docs (JSON list, each with "docname")
```

`delete_items` runs as a background job when it gets more than 10 names.

### Other v2 behavior

- `PUT` and `PATCH` on `/api/v2/document/<DocType>/<name>/` both update. `DELETE` returns HTTP 202 with `"ok"`.
- A document method call checks permission by HTTP verb: GET needs `read`, POST needs `write`. The response has `docs` (the updated document) next to `data`.
- A static `get_list(query)` method on the controller can change the v2 list query. It gets and must return a query builder object.
- The v1 surface still works: `/api/method/<dotted.path>` (also `/api/v1/...`) and `/api/resource/<DocType>[/<name>]`. v1 lists use `limit_page_length` (default 20).

Only create custom `@frappe.whitelist()` endpoints for logic that goes beyond CRUD.

## Specify HTTP methods

Always declare allowed HTTP methods explicitly. Frappe commits after POST, PUT, PATCH and DELETE. GET requests roll back, and CSRF is not checked for GET. So a method that writes must not allow GET.

```python
@frappe.whitelist(methods=["GET"])
def get_dashboard_data(): ...

@frappe.whitelist(methods=["POST"])
def submit_entry(name: str): ...

@frappe.whitelist(methods=["GET", "POST"])
def get_or_create_token(): ...
```

## Anti-patterns

- **Don't wrap doc methods in standalone APIs.** If the controller has `@frappe.whitelist()` on a method, clients call it directly via `frm.call("approve")` or `POST /api/v2/document/Expense/EXP-001/method/approve`. Don't create a separate `api.py` function that just fetches the doc and calls the same method.
- **Don't put doc-scoped logic in standalone APIs.** If the function fetches one doc, validates the caller, and acts on that doc — it belongs as a doc-level `@frappe.whitelist()` method, not in `api/`. Reserve standalone APIs for cross-document operations, aggregations, or endpoints with no document context.
- **Don't leak sensitive fields in guest APIs.** With `allow_guest=True`, only return fields guests need. Never expose `user` (email), internal IDs, or permission-sensitive data.
